/**
 * ⚡ PUERTO — lo define el DOMINIO, no la base de datos.
 * Dice QUÉ necesita el negocio, en su idioma. Cualquier adaptador
 * (Supabase, memoria, MySQL…) que cumpla este contrato se puede enchufar.
 */
import type { EstadoPedido, LineaPedido, OrigenPedido, PrecioProducto } from "./pedido";

export type NuevoPedido = {
  tenantId: string;
  clienteId: number;
  origen: OrigenPedido;
  estado: EstadoPedido;
  lineas: LineaPedido[];
  subtotal: number;
  descuento: number;
  total: number;
};

export interface PedidoRepository {
  /** Productos activos del tenant con su precio vigente. */
  catalogoActivo(tenantId: string): Promise<PrecioProducto[]>;
  /** Guarda el pedido con sus líneas y devuelve su número correlativo. */
  guardar(pedido: NuevoPedido): Promise<{ id: number; numeroPedido: number }>;
}
