/**
 * 🎯 DOMINIO — reglas de negocio puras de un pedido.
 * CERO imports de Next.js, Supabase o React: este archivo no sabe que existe
 * una base de datos ni una pantalla. Es el centro de la cebolla.
 */

export const FLUJO_ESTADOS = [
  "pendiente",
  "confirmado",
  "en_preparacion",
  "despachado",
  "entregado",
] as const;

export type EstadoPedido = (typeof FLUJO_ESTADOS)[number] | "anulado";
export type OrigenPedido = "vendedor" | "cliente_portal";

/** pendiente → confirmado → en_preparacion → despachado → entregado */
export function siguienteEstado(estado: EstadoPedido): EstadoPedido | null {
  const idx = FLUJO_ESTADOS.indexOf(estado as (typeof FLUJO_ESTADOS)[number]);
  if (idx === -1 || idx === FLUJO_ESTADOS.length - 1) return null;
  return FLUJO_ESTADOS[idx + 1];
}

/** Regla: lo que pide el vendedor ya va confirmado; lo del portal queda pendiente. */
export function estadoInicial(origen: OrigenPedido): EstadoPedido {
  return origen === "vendedor" ? "confirmado" : "pendiente";
}

export type PrecioProducto = { id: number; precio: number };

export type LineaPedido = {
  productoId: number;
  cantidad: number;
  precioUnitario: number;
  subtotal: number;
};

/**
 * Arma las líneas con el precio del CATÁLOGO, nunca con el que mande el
 * formulario. Ignora cantidades en cero, negativas o que no son número.
 */
export function armarLineas(
  catalogo: PrecioProducto[],
  cantidades: Map<number, number>,
): LineaPedido[] {
  return catalogo
    .map((p) => ({ producto: p, cantidad: cantidades.get(p.id) ?? 0 }))
    .filter(({ cantidad }) => Number.isFinite(cantidad) && cantidad > 0)
    .map(({ producto, cantidad }) => ({
      productoId: producto.id,
      cantidad,
      precioUnitario: Number(producto.precio),
      subtotal: cantidad * Number(producto.precio),
    }));
}

export function calcularTotales(lineas: LineaPedido[]) {
  const subtotal = lineas.reduce((acc, l) => acc + l.subtotal, 0);
  const descuento = 0;
  return { subtotal, descuento, total: subtotal - descuento };
}
