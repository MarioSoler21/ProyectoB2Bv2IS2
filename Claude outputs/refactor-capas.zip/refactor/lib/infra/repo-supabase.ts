/**
 * 🔌 ADAPTADOR 2 · Supabase — el ÚNICO archivo del flujo de pedidos que sabe
 * de tablas, columnas snake_case y supabase-js. Traduce el idioma del negocio
 * (catalogoActivo, guardar) al idioma de la base de datos.
 */
import { createAdminClient } from "@/lib/supabase/admin";
import type { NuevoPedido, PedidoRepository } from "../domain/puertos";

export function repoSupabase(): PedidoRepository {
  const supabase = createAdminClient();

  return {
    async catalogoActivo(tenantId) {
      const { data, error } = await supabase
        .from("productos")
        .select("id, precio")
        .eq("tenant_id", tenantId)
        .eq("activo", true);
      if (error) throw error;
      return (data ?? []).map((p) => ({ id: p.id, precio: Number(p.precio) }));
    },

    async guardar(pedido: NuevoPedido) {
      const { data, error } = await supabase
        .from("pedidos")
        .insert({
          tenant_id: pedido.tenantId,
          cliente_id: pedido.clienteId,
          origen: pedido.origen,
          estado: pedido.estado,
          subtotal: pedido.subtotal,
          descuento: pedido.descuento,
          total: pedido.total,
        })
        .select("id, numero_pedido") // numero_pedido lo pone el trigger trg_20_set_numero_pedido
        .single();
      if (error) throw error;

      const { error: itemsError } = await supabase.from("pedido_items").insert(
        pedido.lineas.map((l) => ({
          tenant_id: pedido.tenantId,
          pedido_id: data.id,
          producto_id: l.productoId,
          cantidad: l.cantidad,
          precio_unitario: l.precioUnitario,
          subtotal: l.subtotal,
        })),
      );
      if (itemsError) throw itemsError;

      return { id: data.id as number, numeroPedido: data.numero_pedido as number };
    },
  };
}
