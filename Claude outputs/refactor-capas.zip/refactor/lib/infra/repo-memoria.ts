/**
 * 🔌 ADAPTADOR 1 · memoria — cumple el mismo contrato que Supabase.
 * Es el "fake" del M4: sirve para testear el caso de uso sin base de datos.
 */
import type { PrecioProducto } from "../domain/pedido";
import type { NuevoPedido, PedidoRepository } from "../domain/puertos";

export function repoMemoria(
  catalogoPorTenant: Record<string, PrecioProducto[]>,
): PedidoRepository & { guardados: NuevoPedido[] } {
  const guardados: NuevoPedido[] = [];
  const contadores = new Map<string, number>();

  return {
    guardados,
    async catalogoActivo(tenantId) {
      return catalogoPorTenant[tenantId] ?? [];
    },
    async guardar(pedido) {
      guardados.push(pedido);
      const numero = (contadores.get(pedido.tenantId) ?? 0) + 1;
      contadores.set(pedido.tenantId, numero);
      return { id: guardados.length, numeroPedido: numero };
    },
  };
}
