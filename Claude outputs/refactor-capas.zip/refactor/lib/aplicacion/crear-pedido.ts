/**
 * ⚙️ CASO DE USO — orquesta el dominio. Recibe el repositorio por parámetro
 * (la D de SOLID): no sabe si detrás hay Supabase o un arreglo en memoria.
 * Lo usan tanto el vendedor (/mis-clientes) como el portal del cliente
 * (/pedidos/[token]/cliente): antes esta lógica estaba copiada en los dos.
 */
import {
  armarLineas,
  calcularTotales,
  estadoInicial,
  type OrigenPedido,
} from "../domain/pedido";
import type { PedidoRepository } from "../domain/puertos";

export type CrearPedidoInput = {
  tenantId: string;
  clienteId: number;
  origen: OrigenPedido;
  cantidades: Map<number, number>;
};

export async function crearPedido(repo: PedidoRepository, input: CrearPedidoInput) {
  const catalogo = await repo.catalogoActivo(input.tenantId);
  const lineas = armarLineas(catalogo, input.cantidades);
  if (lineas.length === 0) {
    throw new Error("Elegí al menos un producto con cantidad mayor a cero.");
  }

  return repo.guardar({
    tenantId: input.tenantId,
    clienteId: input.clienteId,
    origen: input.origen,
    estado: estadoInicial(input.origen),
    lineas,
    ...calcularTotales(lineas),
  });
}
