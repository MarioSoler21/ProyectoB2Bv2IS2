"use server";

import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import { crearPedido as crearPedidoCasoDeUso } from "@/lib/aplicacion/crear-pedido";
import { repoSupabase } from "@/lib/infra/repo-supabase";

/** 🖥️ INTERFAZ (borde): traduce el FormData y llama al caso de uso. Sin reglas de negocio. */
export async function crearPedido(formData: FormData) {
  const tenant = await getSession();
  if (!tenant) throw new Error("No hay tenant activo");

  await crearPedidoCasoDeUso(repoSupabase(), {
    tenantId: tenant.id,
    clienteId: Number(formData.get("clienteId")),
    origen: "vendedor",
    cantidades: leerCantidades(formData),
  });

  redirect("/despacho");
}

/** Lee los inputs "cantidad_<productoId>" del formulario. */
function leerCantidades(formData: FormData) {
  const cantidades = new Map<number, number>();
  for (const [clave, valor] of formData.entries()) {
    if (clave.startsWith("cantidad_")) {
      cantidades.set(Number(clave.slice("cantidad_".length)), Number(valor));
    }
  }
  return cantidades;
}
