"use server";

import { redirect } from "next/navigation";
import { getClientePorToken } from "@/lib/data/portal";
import { crearPedido } from "@/lib/aplicacion/crear-pedido";
import { repoSupabase } from "@/lib/infra/repo-supabase";

/**
 * 🖥️ INTERFAZ (borde) del portal sin login. El cliente y el tenant salen del
 * token en el servidor; del formulario solo se usan las cantidades.
 */
export async function enviarPedidoCliente(formData: FormData) {
  const token = String(formData.get("token") ?? "");
  const cliente = await getClientePorToken(token);
  if (!cliente) throw new Error("Token invalido o cliente inactivo.");

  const cantidades = new Map<number, number>();
  for (const [clave, valor] of formData.entries()) {
    if (clave.startsWith("cantidad_")) {
      cantidades.set(Number(clave.slice("cantidad_".length)), Number(valor));
    }
  }

  const pedido = await crearPedido(repoSupabase(), {
    tenantId: String(cliente.tenant_id),
    clienteId: cliente.id,
    origen: "cliente_portal",
    cantidades,
  });

  redirect(
    `/pedidos/${encodeURIComponent(token)}/cliente?pedido=${pedido.numeroPedido}`,
  );
}
