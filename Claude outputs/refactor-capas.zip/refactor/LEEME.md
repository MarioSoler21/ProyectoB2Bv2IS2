# Refactor de capas — dónde va cada archivo en tu proyecto

| Archivo de esta carpeta | Va en tu proyecto | Capa |
|---|---|---|
| lib/domain/pedido.ts | lib/domain/pedido.ts (nuevo) | 🎯 Dominio |
| lib/domain/puertos.ts | lib/domain/puertos.ts (nuevo) | 🎯 Dominio (puerto) |
| lib/aplicacion/crear-pedido.ts | lib/aplicacion/crear-pedido.ts (nuevo) | ⚙️ Caso de uso |
| lib/infra/repo-supabase.ts | lib/infra/repo-supabase.ts (nuevo) | 🔌 Adaptador |
| lib/infra/repo-memoria.ts | lib/infra/repo-memoria.ts (nuevo) | 🔌 Adaptador (fake de test) |
| app/(dashboard)/mis-clientes/actions.ts | reemplaza el actual | 🖥️ Interfaz |
| app/pedidos/[token]/cliente/actions.ts | reemplaza el actual | 🖥️ Interfaz |
| lib-data-pedidos-nuevo-inicio.ts | reemplazá el inicio de lib/data/pedidos.ts | re-export |
| tests/crear-pedido.test.ts | tests/crear-pedido.test.ts (nuevo) | test |

Correr los tests (sin Supabase, sin .env):

    npx tsx --test tests/crear-pedido.test.ts

Después: `npm run build` para confirmar que compila, y probá crear un pedido desde /mis-clientes.
Cambio de comportamiento a revisar: el vendedor ya no puede pedir productos INACTIVOS (antes sí).
