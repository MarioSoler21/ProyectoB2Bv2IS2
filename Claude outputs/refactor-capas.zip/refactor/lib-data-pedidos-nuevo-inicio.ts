// lib/data/pedidos.ts — reemplazá el bloque de FLUJO_ESTADOS / EstadoPedido /
// siguienteEstado por este re-export, así despacho/page.tsx y estado-badge.tsx
// siguen funcionando sin tocarlos:
export { FLUJO_ESTADOS, siguienteEstado, type EstadoPedido } from "@/lib/domain/pedido";
import type { EstadoPedido } from "@/lib/domain/pedido";
