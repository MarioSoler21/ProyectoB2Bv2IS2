/**
 * Tests del caso de uso con el adaptador en MEMORIA: corren sin Supabase,
 * sin red y sin .env. Correr con:  npx tsx --test tests/crear-pedido.test.ts
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import { crearPedido } from "../lib/aplicacion/crear-pedido";
import { repoMemoria } from "../lib/infra/repo-memoria";
import { siguienteEstado } from "../lib/domain/pedido";

const catalogo = {
  "1": [
    { id: 10, precio: 25 }, // Libra de frijoles
    { id: 11, precio: 120 }, // Caja de galletas
  ],
  "2": [{ id: 20, precio: 300 }], // Saco de cemento (otra distribuidora)
};

test("el total sale del precio del catálogo, no del formulario", async () => {
  const repo = repoMemoria(catalogo);
  await crearPedido(repo, {
    tenantId: "1",
    clienteId: 5,
    origen: "vendedor",
    cantidades: new Map([[10, 4], [11, 1]]),
  });
  assert.equal(repo.guardados[0].total, 4 * 25 + 120);
});

test("vendedor → confirmado · portal → pendiente", async () => {
  const repo = repoMemoria(catalogo);
  const base = { tenantId: "1", clienteId: 5, cantidades: new Map([[10, 1]]) };
  await crearPedido(repo, { ...base, origen: "vendedor" });
  await crearPedido(repo, { ...base, origen: "cliente_portal" });
  assert.deepEqual(repo.guardados.map((p) => p.estado), ["confirmado", "pendiente"]);
});

test("ignora cantidades en cero o negativas y falla si no queda nada", async () => {
  const repo = repoMemoria(catalogo);
  await assert.rejects(
    crearPedido(repo, {
      tenantId: "1",
      clienteId: 5,
      origen: "cliente_portal",
      cantidades: new Map([[10, 0], [11, -3]]),
    }),
    /al menos un producto/,
  );
});

test("un producto de OTRA distribuidora no entra al pedido", async () => {
  const repo = repoMemoria(catalogo);
  await assert.rejects(
    crearPedido(repo, {
      tenantId: "1",
      clienteId: 5,
      origen: "vendedor",
      cantidades: new Map([[20, 2]]), // el 20 es del tenant 2
    }),
  );
});

test("el correlativo es por distribuidora", async () => {
  const repo = repoMemoria(catalogo);
  const a = await crearPedido(repo, { tenantId: "1", clienteId: 5, origen: "vendedor", cantidades: new Map([[10, 1]]) });
  const b = await crearPedido(repo, { tenantId: "2", clienteId: 9, origen: "vendedor", cantidades: new Map([[20, 1]]) });
  assert.equal(a.numeroPedido, 1);
  assert.equal(b.numeroPedido, 1);
});

test("flujo de estados", () => {
  assert.equal(siguienteEstado("pendiente"), "confirmado");
  assert.equal(siguienteEstado("entregado"), null);
  assert.equal(siguienteEstado("anulado"), null);
});
